const substitutes = {
    ' ': '-',
    '#': 'number-'
};

export default substitutes;
