import './App.scss';
import React, {useState, useRef, useEffect} from "react";
import axios from "axios";
import Dummy from "./helpers/Dummy";
import List from "./helpers/List";
import {leaders} from './leaderboard';
import useDebounce from "./hooks/useDebounce";
import Modal from "./helpers/Modal";
import substitutes from './substitutes';

function App() {
    const baseUrl = `https://www.codewars.com/api/v1/users/`;
    const extraUrl = `https://www.codewars.com/api/v1/code-challenges/`;
    // const leadersUrl = `https://cors-anywhere.herokuapp.com/https://www.codewars.com/users/leaderboard`;
    const [savedUserData, setSavedUserData] = useState({});
    const [sourceUserPages, setSourceUserPages] = useState(null);
    const [targetUserPages, setTargetUserPages] = useState(null);

    const [sourceUser, setSourceUser] = useState('');
    const [targetUser, setTargetUser] = useState('');

    const [list, setList] = useState([]);
    const [category, setCategory] = useState('completed');
    const [disclosure, setDisclosure] = useState(false);
    const [userCustomList, setUserCustomList] = useState(false);

    const [sourceUserStatusSuccess, setSourceUserStatusSuccess] = useState(false);
    const [targetUserStatusSuccess, setTargetUserStatusSuccess] = useState(false);
    const [sourceUserStatusFail, setSourceUserStatusFail] = useState(false);
    const [targetUserStatusFail, setTargetUserStatusFail] = useState(false);

    const [loading, setLoading] = useState(false);
    const [searchActive, setSearchActive] = useState(false);
    const [nonJsThrown, setNonJsThrown] = useState(true);

    const [top500, setTop500] = useState([]);
    const [sourceUserSuggested, setSourceUserSuggested] = useState([]);
    const [targetUserSuggested, setTargetUserSuggested] = useState([]);

    const [modalVisible, setModalVisible] = useState(false);

    const tooltip = useRef();

    const handleUserInput = async (type, val) => {
        type === 'source' ? setSourceUserStatusSuccess(false) : setTargetUserStatusSuccess(false);
        type === 'source' ? setSourceUserStatusFail(false) : setTargetUserStatusFail(false);
        type === 'source' ? setSourceUser(val.trim()) : setTargetUser(val.trim());

        if (type === 'source') {
            setSourceUserSuggested(top500.filter(el => el.userName.startsWith(val)));
        } else {
            setTargetUserSuggested(top500.filter(el => el.userName.startsWith(val)));
        }
        if (val.trim()) {
            delayedInputHandling(type, val);
        }

    };

    const handleUserCheck = async (type, username) => {
        try {
            const res = await axios.get(`${baseUrl}${username}`);
            type === 'source' ? setSourceUserStatusSuccess(true) : setTargetUserStatusSuccess(true);
            type === 'source' ? setSourceUserStatusFail(false) : setTargetUserStatusFail(false);
            type === 'source' ? setSourceUserPages(Math.ceil(res.data.codeChallenges.totalCompleted / 200)) : setTargetUserPages(Math.ceil(res.data.codeChallenges.totalCompleted / 200));
        } catch (e) {
            type === 'source' ? setSourceUserStatusFail(true) : setTargetUserStatusFail(true);
            type === 'source' ? setSourceUserStatusSuccess(false) : setTargetUserStatusSuccess(false);
        }
    };

    const handleInputValidation = async (type, username) => {
        try {
            const res = await axios.get(`${baseUrl}${username}`);
            if (res) {
                type === 'source' ? setSourceUserStatusSuccess(true) : setTargetUserStatusSuccess(true);
                type === 'source' ? setSourceUserPages(Math.ceil(res.data.codeChallenges.totalCompleted / 200)) : setTargetUserPages(Math.ceil(res.data.codeChallenges.totalCompleted / 200));
            }
        } catch (e) {
        }
    };

    // todo someday: all that is open must be closed
    // const handleLeaderBoardFetch = async url => {
    //     // https://stackoverflow.com/questions/597907/open-webpage-and-parse-it-using-javascript
    //
    //     const req = new XMLHttpRequest();
    //     req.open('GET', url, false);
    //     req.send(null);
    //
    //     let data;
    //
    //     if(req.status === 200) {
    //         const html = req.responseText;
    //         const cutStart = html.indexOf('data-username'), cutEnd = html.lastIndexOf('data-username');
    //         const cleaned = html.substring(cutStart, cutEnd + 50);
    //         const arr = cleaned.split('<\/tr><tr ').map(el => {
    //             const strEnd = el.indexOf('>');
    //             return el.substring(0, strEnd);
    //         });
    //         data = arr.map(el => {
    //             return {userName: el.split('=')[1].replace(/"/g, '')};
    //         });
    //     }
    //     setTop500(data);
    // };

    const handleLeaderBoardFetch = () => {
        let data;

        const html = leaders;
        const cutStart = html.indexOf('data-username'), cutEnd = html.lastIndexOf('data-username');
        const cleaned = html.substring(cutStart, cutEnd + 50);
        const arr = cleaned.split('</tr><tr ').map(el => {
            const strEnd = el.indexOf('>');
            return el.substring(0, strEnd);
        });
        data = arr.map(el => {
            return {userName: el.split('=')[1].replace(/"/g, '')};
        });

        setTop500(data);
    };

    const handleKataFetch = async (username, pageSize, isAuth) => {
        setLoading(true);
        let total = [];

        if (isAuth) {
            const res = await axios.get(`https://www.codewars.com/api/v1/users/${username}/code-challenges/authored`);
            total = total.concat(res.data);
        } else {
            while (pageSize >= 0) {
                const chunk = await axios.get(`${baseUrl}${username}/code-challenges/completed?page=${pageSize}`);
                total = total.concat(chunk.data);
                pageSize--;
            }
        }

        total = [].concat(...total.map(el => el.data)).filter(el => {
            if (el) {
                if (el.completedLanguages) {
                    return nonJsThrown ? el.completedLanguages.includes('javascript') : el;
                } else if (el.languages) {
                    return nonJsThrown ? el.languages.includes('javascript') : el;
                } else {
                    return el;
                }
            }
        });
        setLoading(false);
        return total;
    };

    const handleFormSubmit = async e => {
        e.preventDefault();
        const targetKey = `${targetUser}_${category}`;
        const set1 = sourceUser in savedUserData ? savedUserData[sourceUser] : await handleKataFetch(sourceUser, sourceUserPages);
        const set2 = targetKey in savedUserData ? savedUserData[targetKey] : await handleKataFetch(targetUser, targetUserPages, category === 'authored');
        setSavedUserData({...savedUserData, [sourceUser]: set1, [targetKey]: set2});

        const names = set1.map(el => el.name);
        let found = set2.filter(kata => kata.name && names.indexOf(kata.name) < 0);
        let duplicates = found.map(el => el.id);
        duplicates = duplicates.filter((el, i, arr) => arr.indexOf(el) < arr.lastIndexOf(el));
        found = found.filter(el => duplicates.indexOf(el.id) < 0);
        setList(found);
        setSearchActive(true);
        setDisclosure(true);
    };

    const handleRankDisclosure = async () => {
        setDisclosure(false);
        const listWithKataInfo = list.map(async el => {
            const kata = JSON.parse(JSON.stringify(el));
            const res = await axios.get(`${extraUrl}${kata.id}`);

            const rankClasses = [
                [[1, 2], 'violet'],
                [[3, 4], 'blue'],
                [[5, 6], 'yellow'],
                [[7, 8], 'white'],
            ];
            const color = rankClasses.find(el => el[0].includes(parseInt(res.data.rank.name)));
            kata.receivedColor = color ? color[1] : null;
            return kata;
        });

        try {
            const listWithKataRank = await Promise.all(listWithKataInfo);
            setList(listWithKataRank);
            setUserCustomList(true);
        } catch (e) {
            window.alert('Требуемая операция оказалась излишне ресурсоёмкой. \nСтраница будет перезагружена.');
            setTimeout(() => {
                window.location.reload();
            }, 1000);
        }
    };

    const handleModalOpening = () => {
        setModalVisible(true);
        setUserCustomList(false);
    };

    const handleModalClose = () => {
      setModalVisible(false);
    };

    const handleModalFeedback = async data => {
        const customArray = data.toLowerCase().split('\n').map(el => {
            return el.trim().split('').map(sym => /[0-9a-z\-]/i.test(sym) ? sym : substitutes[sym] || '').join('').replace(/-{2,}/g, '-');
        });
        const set1 = sourceUser in savedUserData ? savedUserData[sourceUser] : await handleKataFetch(sourceUser, sourceUserPages);
        const pending = customArray.map(async el => await axios.get(`${extraUrl}${el}`));

        try {
            let set2 = await Promise.all(pending);
            set2 = await set2.map(el => el.data);
            const names = set1.map(el => el.name);
            let found = set2.filter(kata => kata.name && names.indexOf(kata.name) < 0);
            let duplicates = found.map(el => el.id);
            duplicates = duplicates.filter((el, i, arr) => arr.indexOf(el) < arr.lastIndexOf(el));
            found = found.filter(el => duplicates.indexOf(el.id) < 0);
            setList(found);
            setSearchActive(true);
            setModalVisible(false);
        } catch (e) {
            window.alert('Увы! Возможны следующие причины неудачи:\n\n - текст слишком велик;\n - текст содержит символы, приведшие к ошибкам парсинга;\n - задачи с таким именем не существует.\n\n Попробуйте что-нибудь удалить.');
        }
    };


    const handleCheckboxProcessing = () => {
        setNonJsThrown(!nonJsThrown);
        const cleanedUserData = {};
        for (const key in savedUserData) {
            if (savedUserData.hasOwnProperty(key)) {
                if (key.startsWith(sourceUser) || key.startsWith(targetUser)) {
                    continue;
                }
                cleanedUserData[key] = savedUserData[key];
            }
        }
        setSavedUserData(cleanedUserData);
    };

    const handleTooltipVisibility = e => {
        tooltip.current.style.left = (e.screenX + 20) + 'px';
        tooltip.current.style.top = (e.screenY - 40) + 'px';
    };

    const handleCategoryChange = e => {
        setCategory(e.target.value);
    };

    const delayedInputHandling = useDebounce(async (type, val) => {
        await handleInputValidation(type, val);
    }, 1000);

    useEffect(() => {
        handleLeaderBoardFetch();
        window.onclick = () => {
            setSourceUserSuggested([]);
            setTargetUserSuggested([]);
        }
    }, []);

    if (loading) {
        return <Dummy/>
    }

    return (
        <>
            <div className="wrapper">
                <p>Функциональное приращение <a
                    href="https://theoriaarhidoxa.github.io/katas-v5/">предыдущего</a> проекта.
                </p><br/>
                <p>При загрузке приложения парсится &laquo;псевдоответ&raquo; top-500 CodeWars (CORS на фронтенде не
                    победить), и полученные данные используются в подсказках при вводе.</p><br/>
                <p>По ходу дальнейшего набора текста вводимое имя сравнивается на совпадение с каким-либо пользователем
                    (не только top-500); при наличии такового кнопка блокируется, т.к. дальнейшие проверки не
                    нужны. Нечто вроде бэкстейдж-валидации.</p>

                <form className='wrapper__form' onSubmit={handleFormSubmit}>
                    <div className='wrapper__form-block'>
                        <input
                            className={sourceUserStatusSuccess ? 'validInput' : sourceUserStatusFail ? 'invalidInput' : ''}
                            type='text' placeholder='user1: ваш ник на CodeWars' value={sourceUser}
                            onChange={e => handleUserInput('source', e.target.value)}/>
                        <button disabled={sourceUserStatusSuccess} className='btn' type='button'
                                onClick={() => handleUserCheck('source', sourceUser)}>{sourceUserStatusSuccess ? 'Проверено' : 'Проверить'}</button>
                        {sourceUserStatusFail && <p>Пользователь {sourceUser} не найден.</p>}
                        {sourceUserSuggested.length > 0 && sourceUserSuggested.length < 500 &&
                        <ul>
                            {sourceUserSuggested.map(el => {
                                return (
                                    <li key={el.userName} onClick={() => handleUserInput('source', el.userName)}
                                        className={el.userName === 'catchaser' ? 'root' : ''}>{el.userName}</li>
                                )
                            })}
                        </ul>}
                    </div>

                    <div className='wrapper__form-block'>
                        <input
                            className={targetUserStatusSuccess ? 'validInput' : targetUserStatusFail ? 'invalidInput' : ''}
                            type='text' placeholder='user2: у кого будем искать?' value={targetUser}
                            onChange={e => handleUserInput('target', e.target.value)}/>
                        <button disabled={targetUserStatusSuccess} className='btn' type='button'
                                onClick={() => handleUserCheck('target', targetUser)}>{targetUserStatusSuccess ? 'Проверено' : 'Проверить'}</button>
                        {targetUserStatusFail && <p>Пользователь {targetUser} не найден.</p>}
                        {targetUserSuggested.length > 0 && targetUserSuggested.length < 500 &&
                        <ul>
                            {targetUserSuggested.map(el => {
                                return (
                                    <li key={el.userName} onClick={() => handleUserInput('target', el.userName)}
                                        className={el.userName === 'catchaser' ? 'root' : ''}>{el.userName}</li>
                                )
                            })}
                        </ul>}
                    </div>

                    {sourceUser && targetUser && sourceUser === targetUser &&
                    <div className='wrapper__form-warning'><p>Имена пользователей совпадают, поиск не будет
                        продолжен!</p>
                    </div>}

                    <div className='wrapper__form-searchOptions'>

                        <div className={nonJsThrown ? 'toggleViewedBlock active' : 'toggleViewedBlock'}
                             onClick={handleCheckboxProcessing}>
                            <span><i /></span> <p>Исключить ката без javascript</p>
                        </div>

                        <p onMouseMove={handleTooltipVisibility}>Категория <span className='tooltip' ref={tooltip}>У пользователя есть два практически не пересекающихся списка задач: авторские и решённые.<br/> При обращении к API для их получения используются разные запросы.</span>
                        </p>
                        <select value={category} onChange={handleCategoryChange}>
                            <option value={'completed'}>Искать в решённых</option>
                            <option value={'authored'}>Искать в авторских</option>
                        </select>
                        <button className='btn red' type='submit'
                                disabled={!sourceUserStatusSuccess || !targetUserStatusSuccess || (sourceUser === targetUser)}>Поиск
                        </button>
                    </div>
                </form>

                <div className='wrapper__output'>
                    {searchActive && (list.length > 0 ? <p>Найдено: <b>{list.length}</b>.</p> :
                        <p>Ничего не найдено.</p>)}
                    <div>
                        <List list={list}/>
                    </div>
                </div>
            </div>
            {disclosure && list.length && <button className='btn fixedLeftBottom' onClick={handleRankDisclosure}>Раскрыть ранк найденных задач</button>}
            {userCustomList && <button className='btn fixedRightBottom' onClick={handleModalOpening}>Добавить собственный список</button>}
            {modalVisible && <Modal onModalClose={handleModalClose} onModalFeedback={handleModalFeedback} />}
        </>

    );
}

export default App;
