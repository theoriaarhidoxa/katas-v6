import React, {useState, useEffect} from 'react';
import axios from "axios";


const List = ({list}) => {
    const [loading, setLoading] = useState(false);
    const baseUrl = `https://www.codewars.com/api/v1/code-challenges/`;
    const [currentKataId, setCurrentKataId] = useState(null);
    const [currentKataRank, setCurrentKataRank] = useState(null);

    useEffect(() => {

        let timer = setTimeout(() => {
            setCurrentKataId(null);
            setCurrentKataRank(null);
        }, 1000);

        return () => clearTimeout(timer);
    }, [currentKataId, currentKataRank]);

    const handleRankFetching = async (id, e) => {
        e.stopPropagation();
        const rankClasses = [
            [[1, 2], 'violet'],
            [[3, 4], 'blue'],
            [[5, 6], 'yellow'],
            [[7, 8], 'white'],
        ];
        setLoading(true);
        setCurrentKataId(id);
        const res = await axios.get(`${baseUrl}${id}`);
        setCurrentKataRank(res.data.rank.name);
        const rank = rankClasses.find(el => el[0].includes(parseInt(res.data.rank.name)));
        e.target.classList.add(rank ? rank[1] : 'x');
        setLoading(false);
    };

    return (
        <>
            <ul>
                {list.map((el, i) => {
                    return (
                        <li key={el.id}><p>{i + 1}. {el.name} <i className={el.receivedColor ? el.receivedColor : ''} onClick={event => handleRankFetching(el.id, event)}>&#9873; {!loading && el.id === currentKataId && <span className={loading ? 'tooltip blurred' : 'tooltip'}>{loading ? 'kuy' : currentKataRank || 'Not ranked'}</span>}</i></p><a target='_blank' href={`https://www.codewars.com/kata/${el.id}`}>Перейти к задаче</a></li>
                    )
                })}
            </ul>
        </>
    );
};

export default List;
