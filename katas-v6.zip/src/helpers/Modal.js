import React, {useState} from 'react';

const Modal = ({onModalClose, onModalFeedback}) => {
    const [value, setValue] = useState('');
    const handleDataSubmission = () => {
        onModalFeedback(value);
    };

    return (
        <>
            <div className='backdrop' onClick={() => onModalClose()} />
            <div className='modal'>
                <p>Если у вас имеется свой wishlist (или стянутый с раздела <a href='https://www.codewars.com/kata/latest' target='_blank' rel='noreferrer'>practice</a>), есть возможность посмотреть, что в нём ещё не решено (у того, кто в настоящий момент <i>user1</i>, конечно).</p>
                <p>Вставьте список в поле ниже. Названия задач должны располагаться в столбик, с новой строки. После последней строки перенос НЕ нужен.</p>
                <p>Избегайте длинных текстов. На всякий случай, мало ли что &copy;</p>
                <textarea value={value} onChange={e => setValue(e.target.value)} />
                <div>
                    <button className='btn red' onClick={() => onModalClose()}>Закрыть</button>
                    <button disabled={!value} className='btn' onClick={handleDataSubmission}>Поиск</button>
                </div>

            </div>
        </>
    );
};

export default Modal;
